@echo off
:: ================================================================
::  01_SFC_DISM_Repair.bat
::  Repairs Windows system files using DISM then SFC.
::  Run as Administrator. Takes 20-40 minutes. Do not interrupt.
:: ================================================================
TITLE System File Repair - DISM + SFC

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\SFC_DISM_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%_%TIME:~0,2%%TIME:~3,2%.txt
SET LOG=%LOG: =0%

ECHO ================================================================ >> "%LOG%"
ECHO  System File Repair Log                                          >> "%LOG%"
ECHO  Host: %COMPUTERNAME%   Date: %DATE% %TIME%                     >> "%LOG%"
ECHO ================================================================ >> "%LOG%"

ECHO.
ECHO [Step 1/2] Running DISM - restoring Windows component store...
ECHO This can take 15-20 minutes. Please wait.
ECHO.
DISM /Online /Cleanup-Image /RestoreHealth | TEE -a "%LOG%"

ECHO.
ECHO [Step 2/2] Running SFC - scanning and repairing system files...
ECHO.
SFC /SCANNOW | TEE -a "%LOG%"

ECHO.
ECHO ================================================================
ECHO  Complete. Log saved to: %LOG%
ECHO.
ECHO  If SFC found unfixable errors, check:
ECHO    C:\Windows\Logs\CBS\CBS.log
ECHO ================================================================
PAUSE
