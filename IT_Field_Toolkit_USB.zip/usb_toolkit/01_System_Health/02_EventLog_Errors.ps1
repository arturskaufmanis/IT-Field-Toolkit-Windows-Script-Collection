# ================================================================
#  02_EventLog_Errors.ps1
#  Pulls Critical and Error events from System + Application logs
#  for the last 48 hours. Exports to CSV and displays summary.
#  Run as Administrator.
# ================================================================

$LogDir = "C:\Logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

$Since   = (Get-Date).AddHours(-48)
$OutFile = "$LogDir\EventErrors_$env:COMPUTERNAME_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"

Write-Host "`n================================================================" -ForegroundColor Cyan
Write-Host "  Event Log - Critical & Error Events (last 48 hours)" -ForegroundColor Cyan
Write-Host "  Host: $env:COMPUTERNAME" -ForegroundColor Cyan
Write-Host "================================================================`n" -ForegroundColor Cyan

$results = foreach ($log in @('System', 'Application')) {
    Get-WinEvent -FilterHashtable @{
        LogName   = $log
        Level     = 1, 2
        StartTime = $Since
    } -ErrorAction SilentlyContinue |
    Select-Object TimeCreated, Id, LevelDisplayName, ProviderName,
        @{N='Log'; E={$log}},
        @{N='Message'; E={$_.Message -replace "`r`n"," " | Select-Object -First 1}}
}

if ($results) {
    $results | Export-Csv -Path $OutFile -NoTypeInformation
    Write-Host "  Total events found: $($results.Count)" -ForegroundColor Yellow
    Write-Host "  CSV saved to:       $OutFile`n" -ForegroundColor Green

    Write-Host "--- Most frequent Event IDs ---" -ForegroundColor White
    $results | Group-Object Id | Sort-Object Count -Descending | Select-Object -First 15 |
        Format-Table @{N='Count';E={$_.Count}}, @{N='EventID';E={$_.Name}},
            @{N='Source';E={($_.Group[0].ProviderName)}} -AutoSize

    Write-Host "--- Recent Critical Events ---" -ForegroundColor Red
    $results | Where-Object LevelDisplayName -eq 'Critical' |
        Sort-Object TimeCreated -Descending | Select-Object -First 10 |
        Format-Table TimeCreated, Id, ProviderName, Log -AutoSize
} else {
    Write-Host "  No Critical or Error events in the last 48 hours." -ForegroundColor Green
}

Write-Host "`nDone. Press Enter to exit."
Read-Host
