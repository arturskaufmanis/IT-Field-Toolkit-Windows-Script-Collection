@echo off
:: ================================================================
::  03_SystemInfo_Snapshot.bat
::  Full hardware and OS inventory. Saves to log file.
::  Run as Administrator.
:: ================================================================
TITLE System Info Snapshot

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\SysInfo_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

ECHO Collecting system information... Please wait.
ECHO.

ECHO ================================================================ > "%LOG%"
ECHO  SYSTEM INFORMATION SNAPSHOT                                     >> "%LOG%"
ECHO  Host: %COMPUTERNAME%   Date: %DATE% %TIME%                     >> "%LOG%"
ECHO ================================================================ >> "%LOG%"

ECHO [OS and Hardware] >> "%LOG%"
systeminfo >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [CPU Details] >> "%LOG%"
wmic cpu get Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed /format:list >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [RAM Modules] >> "%LOG%"
wmic memorychip get BankLabel,Capacity,Speed,Manufacturer /format:list >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [Disk Drives] >> "%LOG%"
wmic diskdrive get Model,Size,Status,InterfaceType /format:list >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [Logical Disks - Free Space] >> "%LOG%"
wmic logicaldisk get DeviceID,Size,FreeSpace,FileSystem /format:list >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [Graphics Card] >> "%LOG%"
wmic path win32_VideoController get Name,AdapterRAM,DriverVersion /format:list >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [Network Adapters] >> "%LOG%"
wmic nic get Name,MACAddress,NetEnabled /format:list >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [Installed Hotfixes - Last 20] >> "%LOG%"
wmic qfe get HotFixID,InstalledOn,Description | sort /R >> "%LOG%"

ECHO. >> "%LOG%"
ECHO [Running Services] >> "%LOG%"
sc query type= all state= running >> "%LOG%"

ECHO ================================================================
ECHO  Done. Snapshot saved to: %LOG%
ECHO ================================================================
PAUSE
