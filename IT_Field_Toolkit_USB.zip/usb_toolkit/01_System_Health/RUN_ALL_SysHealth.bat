@echo off
title System Health & Repair
color 1F
:MENU
cls
echo.
echo  ============================================================
echo   01  SYSTEM HEALTH ^& REPAIR
echo  ============================================================
echo.
echo   [1]  SysInfo   - Hardware and OS summary (saved to log)
echo   [2]  EventLog  - Critical/Error events last 48 hours
echo   [3]  SFC       - System File Checker scan
echo   [4]  DISM      - Component store restore (needs internet)
echo   [5]  Full Run  - Run all four in sequence
echo   [6]  Back to Main Menu
echo.
set /p CHOICE= Enter number:

if "%CHOICE%"=="1" call "%~dp0SysInfo.bat"
if "%CHOICE%"=="2" call "%~dp0EventLog.bat"
if "%CHOICE%"=="3" call "%~dp0SFC_Scan.bat"
if "%CHOICE%"=="4" call "%~dp0DISM_Repair.bat"
if "%CHOICE%"=="5" goto RUNALL
if "%CHOICE%"=="6" goto END
goto MENU

:RUNALL
call "%~dp0SysInfo.bat"
call "%~dp0EventLog.bat"
call "%~dp0SFC_Scan.bat"
call "%~dp0DISM_Repair.bat"
echo.
echo All System Health checks complete. Check LOGS folder.
pause

:END
