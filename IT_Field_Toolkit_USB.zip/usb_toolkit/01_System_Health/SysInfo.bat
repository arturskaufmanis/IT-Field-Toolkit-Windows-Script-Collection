@echo off
title System Info Snapshot
SET LOGDIR=%~dp0..\..\LOGS
IF NOT EXIST "%LOGDIR%" MKDIR "%LOGDIR%"
SET LOG=%LOGDIR%\SysInfo_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

echo ============================================= > "%LOG%"
echo  SYSTEM INFORMATION SNAPSHOT                 >> "%LOG%"
echo  Machine : %COMPUTERNAME%                    >> "%LOG%"
echo  Date    : %DATE% %TIME%                     >> "%LOG%"
echo ============================================= >> "%LOG%"

echo [OS Information] >> "%LOG%"
systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"System Type" /C:"Total Physical" /C:"Available Physical" /C:"Registered Owner" /C:"System Boot Time" >> "%LOG%"

echo. >> "%LOG%"
echo [CPU] >> "%LOG%"
wmic cpu get Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed /format:list >> "%LOG%"

echo. >> "%LOG%"
echo [Disk Drives] >> "%LOG%"
wmic diskdrive get Model,Size,Status /format:list >> "%LOG%"

echo. >> "%LOG%"
echo [Logical Disks - Free Space] >> "%LOG%"
wmic logicaldisk get DeviceID,Size,FreeSpace,FileSystem /format:list >> "%LOG%"

echo. >> "%LOG%"
echo [Installed RAM Sticks] >> "%LOG%"
wmic memorychip get BankLabel,Capacity,Speed,Manufacturer /format:list >> "%LOG%"

echo. >> "%LOG%"
echo [BIOS] >> "%LOG%"
wmic bios get Manufacturer,Name,Version,ReleaseDate /format:list >> "%LOG%"

echo. >> "%LOG%"
echo [Uptime] >> "%LOG%"
net statistics workstation | findstr "since" >> "%LOG%"

echo SysInfo saved to: %LOG%
echo Done.
pause
