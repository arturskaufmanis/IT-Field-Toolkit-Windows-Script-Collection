@echo off
:: ================================================================
::  04_Net_Diagnostics.bat
::  Full network diagnostic sweep. Saves timestamped log.
::  Run as Administrator.
:: ================================================================
TITLE Network Diagnostics

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\NetDiag_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%_%TIME:~0,2%%TIME:~3,2%.txt
SET LOG=%LOG: =0%

ECHO ================================================================ >> "%LOG%"
ECHO  NETWORK DIAGNOSTICS                                             >> "%LOG%"
ECHO  Host: %COMPUTERNAME%   Date: %DATE% %TIME%                     >> "%LOG%"
ECHO ================================================================ >> "%LOG%"

ECHO Running diagnostics - this will take about 2 minutes...
ECHO.

ECHO [1/8] IP Configuration >> "%LOG%"
ECHO --- IP Configuration --- >> "%LOG%"
ipconfig /all >> "%LOG%"

ECHO [2/8] DNS Cache >> "%LOG%"
ECHO --- DNS Cache --- >> "%LOG%"
ipconfig /displaydns >> "%LOG%"

ECHO [3/8] Routing Table >> "%LOG%"
ECHO --- Routing Table --- >> "%LOG%"
route print >> "%LOG%"

ECHO [4/8] ARP Cache >> "%LOG%"
ECHO --- ARP Cache --- >> "%LOG%"
arp -a >> "%LOG%"

:: Extract default gateway for ping test
FOR /F "tokens=13" %%i IN ('ipconfig ^| findstr /i "Default Gateway" ^| findstr /v "0.0.0.0" ^| findstr /v "::"') DO SET GW=%%i

ECHO [5/8] Ping Gateway (%GW%) >> "%LOG%"
ECHO --- Ping Default Gateway: %GW% --- >> "%LOG%"
ping -n 4 %GW% >> "%LOG%"

ECHO [6/8] Ping 8.8.8.8 (Google DNS) >> "%LOG%"
ECHO --- Ping 8.8.8.8 --- >> "%LOG%"
ping -n 4 8.8.8.8 >> "%LOG%"

ECHO [7/8] Ping google.com (DNS resolution test) >> "%LOG%"
ECHO --- Ping google.com --- >> "%LOG%"
ping -n 4 google.com >> "%LOG%"

ECHO [8/8] Traceroute to 8.8.8.8 >> "%LOG%"
ECHO --- Traceroute to 8.8.8.8 --- >> "%LOG%"
tracert -d -h 20 8.8.8.8 >> "%LOG%"

ECHO. >> "%LOG%"
ECHO --- Active TCP Connections --- >> "%LOG%"
netstat -ano >> "%LOG%"

ECHO. >> "%LOG%"
ECHO --- NetBIOS Statistics --- >> "%LOG%"
nbtstat -s >> "%LOG%"

ECHO.
ECHO ================================================================
ECHO  Network diagnostics complete.
ECHO  Log saved to: %LOG%
ECHO.
ECHO  Quick results:
ECHO  - Gateway:   %GW%
ping -n 1 %GW% | findstr /i "reply" >nul && ECHO  - Gateway:   REACHABLE || ECHO  - Gateway:   UNREACHABLE
ping -n 1 8.8.8.8 | findstr /i "reply" >nul && ECHO  - Internet:  REACHABLE || ECHO  - Internet:  UNREACHABLE
ping -n 1 google.com | findstr /i "reply" >nul && ECHO  - DNS:       RESOLVING || ECHO  - DNS:       NOT RESOLVING
ECHO ================================================================
PAUSE
