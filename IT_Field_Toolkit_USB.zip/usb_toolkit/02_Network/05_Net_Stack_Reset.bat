@echo off
:: ================================================================
::  05_Net_Stack_Reset.bat
::  Resets Winsock, TCP/IP stack, and firewall to defaults.
::  REQUIRES REBOOT after running.
::  Run as Administrator.
:: ================================================================
TITLE Network Stack Reset

ECHO ================================================================
ECHO  NET STACK RESET
ECHO  This will reset: Winsock, TCP/IP stack, firewall defaults
ECHO  A REBOOT IS REQUIRED after this script completes.
ECHO ================================================================
ECHO.
ECHO  Press CTRL+C to cancel, or
PAUSE

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\NetReset_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

ECHO Network Stack Reset - %DATE% %TIME% > "%LOG%"
ECHO Host: %COMPUTERNAME% >> "%LOG%"
ECHO. >> "%LOG%"

ECHO [1/6] Resetting Winsock...
ECHO [Winsock Reset] >> "%LOG%"
netsh winsock reset >> "%LOG%"

ECHO [2/6] Resetting TCP/IP stack...
ECHO [TCP/IP Reset] >> "%LOG%"
netsh int ip reset C:\Logs\ip_reset_detail.log >> "%LOG%"
netsh int ipv6 reset >> "%LOG%"

ECHO [3/6] Resetting firewall to defaults...
ECHO [Firewall Reset] >> "%LOG%"
netsh advfirewall reset >> "%LOG%"

ECHO [4/6] Flushing DNS cache...
ECHO [DNS Flush] >> "%LOG%"
ipconfig /flushdns >> "%LOG%"

ECHO [5/6] Releasing DHCP lease...
ECHO [DHCP Release] >> "%LOG%"
ipconfig /release >> "%LOG%"

ECHO [6/6] Renewing DHCP lease...
ECHO [DHCP Renew] >> "%LOG%"
ipconfig /renew >> "%LOG%"

ECHO [Post-reset IP config] >> "%LOG%"
ipconfig /all >> "%LOG%"

ECHO.
ECHO ================================================================
ECHO  Reset complete. Log saved to: %LOG%
ECHO.
ECHO  *** REBOOT REQUIRED ***
ECHO  Type Y to reboot now, or N to reboot manually later.
ECHO ================================================================
SET /P REBOOT=Reboot now? (Y/N): 
IF /I "%REBOOT%"=="Y" shutdown /r /t 10 /c "IT Toolkit: Network stack reset complete. Rebooting."
IF /I "%REBOOT%"=="N" ECHO Please reboot the machine before testing network connectivity.
PAUSE
