@echo off
:: ================================================================
::  06_DNS_Flush_Renew.bat
::  Flushes DNS cache and renews DHCP lease.
::  Lighter fix - use before escalating to full stack reset.
::  Run as Administrator.
:: ================================================================
TITLE DNS Flush and DHCP Renew

ECHO ================================================================
ECHO  DNS FLUSH + DHCP RENEW
ECHO ================================================================
ECHO.

ECHO [1/4] Flushing DNS resolver cache...
ipconfig /flushdns
ECHO.

ECHO [2/4] Releasing DHCP lease...
ipconfig /release
ECHO.

ECHO [3/4] Waiting 3 seconds...
timeout /t 3 /nobreak >nul

ECHO [4/4] Renewing DHCP lease...
ipconfig /renew
ECHO.

ECHO ================================================================
ECHO  Done. Current IP configuration:
ECHO ================================================================
ipconfig
ECHO.
ECHO  Also registering DNS...
ipconfig /registerdns
ECHO.
PAUSE
