@echo off
:: ================================================================
::  07_Temp_Cleanup.bat
::  Clears Temp folders, Prefetch, WER dumps, and browser caches.
::  Does NOT delete personal files.
::  Run as Administrator.
:: ================================================================
TITLE Temp Files Cleanup

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\Cleanup_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

ECHO ================================================================ > "%LOG%"
ECHO  TEMP FILE CLEANUP - %DATE% %TIME% >> "%LOG%"
ECHO  Host: %COMPUTERNAME% >> "%LOG%"
ECHO ================================================================ >> "%LOG%"

ECHO ================================================================
ECHO  TEMP FILE CLEANUP
ECHO  Close all applications before continuing.
ECHO ================================================================
PAUSE

ECHO [1/7] Windows Temp folder...
DEL /S /F /Q "%SystemRoot%\Temp\*.*" 2>nul
FOR /D %%p IN ("%SystemRoot%\Temp\*") DO RD /S /Q "%%p" 2>nul
ECHO   Windows\Temp cleared. >> "%LOG%"

ECHO [2/7] User Temp folder (%TEMP%)...
DEL /S /F /Q "%TEMP%\*.*" 2>nul
FOR /D %%p IN ("%TEMP%\*") DO RD /S /Q "%%p" 2>nul
ECHO   User TEMP cleared. >> "%LOG%"

ECHO [3/7] Prefetch...
DEL /S /F /Q "%SystemRoot%\Prefetch\*.pf" 2>nul
ECHO   Prefetch cleared. >> "%LOG%"

ECHO [4/7] Windows Error Reporting dumps...
DEL /S /F /Q "%ProgramData%\Microsoft\Windows\WER\ReportQueue\*.*" 2>nul
DEL /S /F /Q "%ProgramData%\Microsoft\Windows\WER\ReportArchive\*.*" 2>nul
ECHO   WER dumps cleared. >> "%LOG%"

ECHO [5/7] Windows Update download cache...
net stop wuauserv >nul 2>&1
DEL /S /F /Q "%SystemRoot%\SoftwareDistribution\Download\*.*" 2>nul
net start wuauserv >nul 2>&1
ECHO   WU download cache cleared. >> "%LOG%"

ECHO [6/7] Thumbnail cache...
DEL /S /F /Q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*.db" 2>nul
ECHO   Thumbnail cache cleared. >> "%LOG%"

ECHO [7/7] Running Disk Cleanup (system files)...
cleanmgr /sagerun:1 >nul 2>&1
ECHO   Disk Cleanup run. >> "%LOG%"

:: Disk space report
ECHO. >> "%LOG%"
ECHO [Disk Free Space After Cleanup] >> "%LOG%"
wmic logicaldisk get DeviceID,FreeSpace,Size /format:list >> "%LOG%"

ECHO.
ECHO ================================================================
ECHO  Cleanup complete. Log saved to: %LOG%
ECHO.
ECHO  Disk space (C:):
FOR /F "tokens=2 delims==" %%i IN ('wmic logicaldisk where "DeviceID='C:'" get FreeSpace /value') DO SET FREE=%%i
ECHO  Free: %FREE% bytes
ECHO ================================================================
PAUSE
