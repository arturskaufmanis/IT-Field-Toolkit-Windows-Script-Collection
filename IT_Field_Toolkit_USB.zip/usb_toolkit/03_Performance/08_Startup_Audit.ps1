# ================================================================
#  08_Startup_Audit.ps1
#  Lists all startup items: registry run keys, startup folders,
#  scheduled tasks, and enabled services set to auto-start.
#  Read-only — no changes made.
#  Run as Administrator.
# ================================================================

$LogDir = "C:\Logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
$OutFile = "$LogDir\StartupAudit_$env:COMPUTERNAME_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"

Write-Host "`n================================================================" -ForegroundColor Cyan
Write-Host "  STARTUP AUDIT — $env:COMPUTERNAME" -ForegroundColor Cyan
Write-Host "================================================================`n" -ForegroundColor Cyan

$entries = [System.Collections.Generic.List[PSObject]]::new()

# --- Registry Run keys ---
$runKeys = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
)
foreach ($key in $runKeys) {
    if (Test-Path $key) {
        (Get-ItemProperty $key).PSObject.Properties |
        Where-Object { $_.Name -notmatch '^PS' } |
        ForEach-Object {
            $entries.Add([PSCustomObject]@{
                Source  = 'Registry'
                Name    = $_.Name
                Command = $_.Value
                Location = $key
            })
        }
    }
}

# --- Startup folders ---
$startupFolders = @(
    "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup",
    "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"
)
foreach ($folder in $startupFolders) {
    if (Test-Path $folder) {
        Get-ChildItem $folder -File | ForEach-Object {
            $entries.Add([PSCustomObject]@{
                Source   = 'StartupFolder'
                Name     = $_.Name
                Command  = $_.FullName
                Location = $folder
            })
        }
    }
}

# --- Scheduled Tasks (enabled, at startup/logon) ---
Get-ScheduledTask | Where-Object {
    $_.State -eq 'Ready' -and
    ($_.Triggers | Where-Object { $_ -is [CimInstance] -and
        ($_.CimClass.CimClassName -match 'Boot|Logon') })
} | ForEach-Object {
    $entries.Add([PSCustomObject]@{
        Source   = 'ScheduledTask'
        Name     = $_.TaskName
        Command  = ($_.Actions | Select-Object -First 1 -ExpandProperty Execute)
        Location = $_.TaskPath
    })
}

# --- Auto-start services ---
Write-Host "--- Auto-Start Services (non-Microsoft) ---" -ForegroundColor Yellow
Get-CimInstance Win32_Service |
    Where-Object { $_.StartMode -eq 'Auto' -and $_.State -eq 'Running' -and
        $_.PathName -notmatch 'system32|SysWOW64' } |
    Select-Object Name, DisplayName, State,
        @{N='Executable';E={$_.PathName}} |
    Sort-Object DisplayName |
    Format-Table -AutoSize

# --- Display startup entries ---
Write-Host "`n--- Registry & Folder Startup Entries ---" -ForegroundColor Yellow
$entries | Format-Table Source, Name, Command -AutoSize -Wrap

$entries | Export-Csv -Path $OutFile -NoTypeInformation
Write-Host "`n$($entries.Count) startup entries found. CSV saved to: $OutFile" -ForegroundColor Green
Write-Host "`nReview for unfamiliar or suspicious entries.`n"
Read-Host "Press Enter to exit"
