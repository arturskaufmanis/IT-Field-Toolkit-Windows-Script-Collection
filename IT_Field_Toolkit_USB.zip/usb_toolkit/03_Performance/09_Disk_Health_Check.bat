@echo off
:: ================================================================
::  09_Disk_Health_Check.bat
::  Reports SMART status for all drives and schedules chkdsk
::  on C: for next reboot if errors are found.
::  Run as Administrator.
:: ================================================================
TITLE Disk Health Check

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\DiskHealth_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

ECHO ================================================================ > "%LOG%"
ECHO  DISK HEALTH CHECK - %DATE% %TIME% >> "%LOG%"
ECHO  Host: %COMPUTERNAME% >> "%LOG%"
ECHO ================================================================ >> "%LOG%"

ECHO ================================================================
ECHO  DISK HEALTH CHECK
ECHO ================================================================
ECHO.

ECHO [1/4] SMART status (all physical drives)...
ECHO [SMART Status] >> "%LOG%"
wmic diskdrive get Model,Size,Status,InterfaceType,SerialNumber /format:list >> "%LOG%"
wmic diskdrive get Model,Status

ECHO.
ECHO [2/4] Disk partitions and free space...
ECHO [Partition / Free Space] >> "%LOG%"
wmic logicaldisk get DeviceID,FileSystem,Size,FreeSpace,VolumeName /format:list >> "%LOG%"
wmic logicaldisk get DeviceID,FileSystem,Size,FreeSpace,VolumeName

ECHO.
ECHO [3/4] Volume dirty bit check (C:)...
ECHO [Dirty Bit - C:] >> "%LOG%"
fsutil dirty query C: >> "%LOG%"
fsutil dirty query C:

ECHO.
ECHO [4/4] Schedule chkdsk on C: for next reboot?
ECHO  (Recommended if SMART shows warnings or dirty bit is set)
SET /P SCHED=Schedule chkdsk /f /r on C: for next boot? (Y/N): 
IF /I "%SCHED%"=="Y" (
    chkdsk C: /f /r /x
    ECHO Chkdsk scheduled for next reboot. >> "%LOG%"
    ECHO Chkdsk will run on next reboot.
) ELSE (
    ECHO Chkdsk not scheduled. >> "%LOG%"
    ECHO Skipped.
)

ECHO.
ECHO ================================================================
ECHO  Disk check complete. Log: %LOG%
ECHO  SMART status key: OK = healthy, Pred Fail = replace soon
ECHO ================================================================
PAUSE
