# ================================================================
#  10_Perf_Snapshot.ps1
#  Point-in-time performance snapshot: CPU, RAM, top processes,
#  disk I/O, pagefile. Good first step for "it's running slow".
#  Run as Administrator.
# ================================================================

$LogDir = "C:\Logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
$OutFile = "$LogDir\PerfSnapshot_$env:COMPUTERNAME_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"

function Write-Log { param($msg) $msg | Tee-Object -FilePath $OutFile -Append | Write-Host }

Write-Log "================================================================"
Write-Log "  PERFORMANCE SNAPSHOT"
Write-Log "  Host: $env:COMPUTERNAME   $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
Write-Log "================================================================`n"

# CPU
$cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
$cpuColor = if ($cpu -gt 85) { 'Red' } elseif ($cpu -gt 60) { 'Yellow' } else { 'Green' }
Write-Host "CPU Usage: $cpu%" -ForegroundColor $cpuColor
"CPU Usage: $cpu%" | Out-File $OutFile -Append

# RAM
$os       = Get-CimInstance Win32_OperatingSystem
$ramTotal = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
$ramFree  = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
$ramUsed  = [math]::Round($ramTotal - $ramFree, 2)
$ramPct   = [math]::Round(($ramUsed / $ramTotal) * 100, 1)
$ramColor = if ($ramPct -gt 90) { 'Red' } elseif ($ramPct -gt 75) { 'Yellow' } else { 'Green' }
Write-Host "RAM: $ramUsed GB used / $ramTotal GB total ($ramPct%)" -ForegroundColor $ramColor
"RAM: $ramUsed GB / $ramTotal GB ($ramPct%)" | Out-File $OutFile -Append

# Uptime
$uptime = (Get-Date) - $os.LastBootUpTime
Write-Log "Uptime: $([math]::Floor($uptime.TotalDays))d $($uptime.Hours)h $($uptime.Minutes)m"

# Top 15 processes by CPU
Write-Log "`n--- Top 15 Processes by CPU ---"
Get-Process | Sort-Object CPU -Descending | Select-Object -First 15 |
    Select-Object Name,
        @{N='CPU(s)';E={[math]::Round($_.CPU,1)}},
        @{N='RAM(MB)';E={[math]::Round($_.WorkingSet64/1MB,1)}},
        Id |
    Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host

# Top 10 by RAM
Write-Log "`n--- Top 10 Processes by RAM ---"
Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 |
    Select-Object Name,
        @{N='RAM(MB)';E={[math]::Round($_.WorkingSet64/1MB,1)}},
        Id |
    Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host

# Disk usage
Write-Log "`n--- Disk Usage ---"
Get-PSDrive -PSProvider FileSystem |
    Select-Object Name,
        @{N='Used(GB)';E={[math]::Round($_.Used/1GB,1)}},
        @{N='Free(GB)';E={[math]::Round($_.Free/1GB,1)}},
        @{N='Total(GB)';E={[math]::Round(($_.Used+$_.Free)/1GB,1)}},
        @{N='Free%';E={[math]::Round(($_.Free/($_.Used+$_.Free))*100,1)}} |
    Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host

# Pagefile
Write-Log "`n--- Pagefile ---"
Get-CimInstance Win32_PageFileUsage |
    Select-Object Name,
        @{N='Current(MB)';E={$_.CurrentUsage}},
        @{N='Peak(MB)';E={$_.PeakUsage}},
        @{N='Max(MB)';E={$_.AllocatedBaseSize}} |
    Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host

Write-Log "`nSnapshot saved to: $OutFile"
Read-Host "`nPress Enter to exit"
