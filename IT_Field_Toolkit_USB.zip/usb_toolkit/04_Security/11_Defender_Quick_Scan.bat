@echo off
:: ================================================================
::  11_Defender_Quick_Scan.bat
::  Updates Defender signatures and runs a Quick Scan.
::  For a full scan, change QuickScan to FullScan (takes longer).
::  Run as Administrator.
:: ================================================================
TITLE Windows Defender Scan

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\DefenderScan_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

ECHO ================================================================ > "%LOG%"
ECHO  WINDOWS DEFENDER SCAN - %DATE% %TIME% >> "%LOG%"
ECHO  Host: %COMPUTERNAME% >> "%LOG%"
ECHO ================================================================ >> "%LOG%"

ECHO ================================================================
ECHO  WINDOWS DEFENDER SCAN
ECHO ================================================================
ECHO.

:: Check Defender service
ECHO [1/3] Checking Windows Defender service...
sc query WinDefend | findstr /i "RUNNING" >nul
IF %ERRORLEVEL% NEQ 0 (
    ECHO Defender service not running. Attempting to start...
    net start WinDefend
)

:: Update signatures
ECHO [2/3] Updating virus definitions...
"%ProgramFiles%\Windows Defender\MpCmdRun.exe" -SignatureUpdate >> "%LOG%" 2>&1
IF %ERRORLEVEL% EQU 0 (
    ECHO Definitions updated successfully.
) ELSE (
    ECHO Could not update definitions ^(offline?^). Proceeding with existing definitions.
)

:: Run quick scan
ECHO [3/3] Running Quick Scan...
ECHO This may take several minutes depending on machine speed.
ECHO.
"%ProgramFiles%\Windows Defender\MpCmdRun.exe" -Scan -ScanType 1 >> "%LOG%" 2>&1

IF %ERRORLEVEL% EQU 0 (
    ECHO Scan complete - No threats found.
    ECHO Result: CLEAN >> "%LOG%"
) ELSE (
    ECHO Scan complete - THREATS MAY HAVE BEEN FOUND.
    ECHO Check Windows Security Centre for details.
    ECHO Result: CHECK REQUIRED >> "%LOG%"
)

ECHO.
ECHO ================================================================
ECHO  Scan log saved to: %LOG%
ECHO  For full results, open Windows Security ^> Virus protection history
ECHO ================================================================
PAUSE
