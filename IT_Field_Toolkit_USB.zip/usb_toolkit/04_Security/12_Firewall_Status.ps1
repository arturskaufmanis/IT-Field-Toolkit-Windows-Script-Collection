# ================================================================
#  12_Firewall_Status.ps1
#  Reports firewall profile status, lists inbound rules that allow
#  traffic, and flags any disabled profiles.
#  Read-only — no changes made.
#  Run as Administrator.
# ================================================================

$LogDir = "C:\Logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
$OutFile = "$LogDir\FirewallStatus_$env:COMPUTERNAME_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"

Write-Host "`n================================================================" -ForegroundColor Cyan
Write-Host "  FIREWALL STATUS — $env:COMPUTERNAME" -ForegroundColor Cyan
Write-Host "================================================================`n" -ForegroundColor Cyan

# Profile status
Write-Host "--- Firewall Profile Status ---" -ForegroundColor Yellow
$profiles = Get-NetFirewallProfile
foreach ($p in $profiles) {
    $color = if ($p.Enabled) { 'Green' } else { 'Red' }
    $status = if ($p.Enabled) { 'ENABLED' } else { 'DISABLED *** CHECK THIS ***' }
    Write-Host "  $($p.Name.PadRight(12)): $status" -ForegroundColor $color
}
$profiles | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction |
    Format-Table -AutoSize | Out-File $OutFile -Append

# Disabled profiles warning
$disabled = $profiles | Where-Object { -not $_.Enabled }
if ($disabled) {
    Write-Host "`n  WARNING: Firewall is DISABLED on: $($disabled.Name -join ', ')" -ForegroundColor Red
    Write-Host "  To re-enable: netsh advfirewall set allprofiles state on" -ForegroundColor Yellow
}

# Inbound allow rules (non-default)
Write-Host "`n--- Inbound Allow Rules (enabled, non-system) ---" -ForegroundColor Yellow
$rules = Get-NetFirewallRule -Direction Inbound -Action Allow -Enabled True |
    Where-Object { $_.DisplayGroup -notmatch 'Core Networking|Windows|@' } |
    Select-Object DisplayName, Profile, DisplayGroup,
        @{N='Program';E={
            ($_ | Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue).Program
        }} |
    Sort-Object DisplayName

if ($rules) {
    $rules | Format-Table -AutoSize -Wrap
    $rules | Out-File $OutFile -Append
    Write-Host "  $($rules.Count) non-system inbound allow rules found." -ForegroundColor Yellow
} else {
    Write-Host "  No non-system inbound allow rules found." -ForegroundColor Green
}

# Outbound block rules
Write-Host "`n--- Outbound Block Rules (if any) ---" -ForegroundColor Yellow
$outboundBlocks = Get-NetFirewallRule -Direction Outbound -Action Block -Enabled True |
    Select-Object DisplayName, Profile, DisplayGroup
if ($outboundBlocks) {
    $outboundBlocks | Format-Table -AutoSize
} else {
    Write-Host "  No custom outbound block rules." -ForegroundColor Green
}

# Check firewall service
Write-Host "`n--- Windows Firewall Service ---" -ForegroundColor Yellow
$svc = Get-Service mpssvc
$color = if ($svc.Status -eq 'Running') { 'Green' } else { 'Red' }
Write-Host "  Service (mpssvc): $($svc.Status)" -ForegroundColor $color

"Report generated: $(Get-Date)" | Out-File $OutFile -Append
Write-Host "`nFull report saved to: $OutFile`n" -ForegroundColor Green
Read-Host "Press Enter to exit"
