@echo off
:: ================================================================
::  13_Windows_Update_Reset.bat
::  Stops WU services, backs up and clears SoftwareDistribution
::  cache, resets BITS, restarts services.
::  Use when updates are stuck, failing, or looping.
::  Run as Administrator. Reboot recommended after.
:: ================================================================
TITLE Windows Update Reset

ECHO ================================================================
ECHO  WINDOWS UPDATE RESET
ECHO  This clears the Windows Update download cache.
ECHO  Services will be stopped briefly, then restarted.
ECHO ================================================================
PAUSE

IF NOT EXIST C:\Logs MKDIR C:\Logs
SET LOG=C:\Logs\WU_Reset_%COMPUTERNAME%_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%.txt

ECHO Windows Update Reset - %DATE% %TIME% > "%LOG%"
ECHO Host: %COMPUTERNAME% >> "%LOG%"
ECHO. >> "%LOG%"

ECHO [1/6] Stopping Windows Update services...
net stop wuauserv >> "%LOG%" 2>&1
net stop cryptSvc >> "%LOG%" 2>&1
net stop bits >> "%LOG%" 2>&1
net stop msiserver >> "%LOG%" 2>&1
ECHO Services stopped. >> "%LOG%"

ECHO [2/6] Backing up SoftwareDistribution folder...
IF EXIST "%SystemRoot%\SoftwareDistribution.bak" (
    ECHO Old backup found. Removing...
    RD /S /Q "%SystemRoot%\SoftwareDistribution.bak"
)
REN "%SystemRoot%\SoftwareDistribution" SoftwareDistribution.bak >> "%LOG%" 2>&1

ECHO [3/6] Backing up catroot2...
IF EXIST "%SystemRoot%\System32\catroot2.bak" (
    RD /S /Q "%SystemRoot%\System32\catroot2.bak"
)
REN "%SystemRoot%\System32\catroot2" catroot2.bak >> "%LOG%" 2>&1

ECHO [4/6] Resetting BITS and Winsock...
netsh winsock reset >> "%LOG%" 2>&1
netsh winsock reset proxy >> "%LOG%" 2>&1
sc.exe sdset bits D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU) >> "%LOG%" 2>&1

ECHO [5/6] Restarting services...
net start wuauserv >> "%LOG%" 2>&1
net start cryptSvc >> "%LOG%" 2>&1
net start bits >> "%LOG%" 2>&1
net start msiserver >> "%LOG%" 2>&1
ECHO Services restarted. >> "%LOG%"

ECHO [6/6] Triggering update detection...
wuauclt /detectnow >> "%LOG%" 2>&1
usoclient StartScan >> "%LOG%" 2>&1

ECHO.
ECHO ================================================================
ECHO  Windows Update reset complete. Log: %LOG%
ECHO.
ECHO  Next steps:
ECHO    1. Reboot the machine
ECHO    2. Open Windows Update and check for updates
ECHO    3. If still failing, run 01_SFC_DISM_Repair.bat
ECHO ================================================================
PAUSE
