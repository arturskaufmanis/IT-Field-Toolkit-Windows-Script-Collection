# ================================================================
#  14_Security_Audit.ps1
#  Read-only security snapshot: open ports, listening services,
#  local users/admins, shared folders, RDP status, UAC, Defender.
#  Run as Administrator.
# ================================================================

$LogDir = "C:\Logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
$OutFile = "$LogDir\SecurityAudit_$env:COMPUTERNAME_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"

function Section($title) {
    $line = "`n--- $title ---"
    Write-Host $line -ForegroundColor Yellow
    $line | Out-File $OutFile -Append
}

$header = @"
================================================================
  SECURITY AUDIT — $env:COMPUTERNAME
  $(Get-Date -Format 'yyyy-MM-dd HH:mm')
================================================================
"@
Write-Host $header -ForegroundColor Cyan
$header | Out-File $OutFile

# --- Local Users ---
Section "Local User Accounts"
Get-LocalUser | Select-Object Name, Enabled,
    @{N='LastLogon';E={if($_.LastLogon){$_.LastLogon.ToString('yyyy-MM-dd')}else{'Never'}}},
    PasswordRequired, PasswordExpires |
    Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host

# --- Local Admins ---
Section "Local Administrators Group"
try {
    Get-LocalGroupMember -Group "Administrators" |
        Select-Object Name, ObjectClass, PrincipalSource |
        Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host
} catch {
    Write-Host "  Could not enumerate Administrators group." -ForegroundColor Red
}

# --- Shared Folders ---
Section "Shared Folders"
$shares = Get-SmbShare | Where-Object { $_.Name -notmatch '^\w+\$$' }
if ($shares) {
    $shares | Select-Object Name, Path, Description |
        Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host
    Write-Host "  NOTE: Non-default shares detected — verify these are intentional." -ForegroundColor Yellow
} else {
    Write-Host "  No non-default shares found." -ForegroundColor Green
    "  No non-default shares." | Out-File $OutFile -Append
}

# --- Listening Ports ---
Section "Listening TCP/UDP Ports"
$ports = Get-NetTCPConnection -State Listen |
    Select-Object LocalPort,
        @{N='Process';E={(Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name}},
        OwningProcess |
    Sort-Object LocalPort
$ports | Format-Table -AutoSize | Tee-Object -FilePath $OutFile -Append | Write-Host

# Flag common risky ports
$riskyPorts = @{23='Telnet';21='FTP';3389='RDP';5900='VNC';139='NetBIOS';445='SMB'}
foreach ($port in $riskyPorts.Keys) {
    if ($ports.LocalPort -contains $port) {
        Write-Host "  WARNING: Port $port ($($riskyPorts[$port])) is OPEN" -ForegroundColor Red
        "  WARNING: Port $port ($($riskyPorts[$port])) is OPEN" | Out-File $OutFile -Append
    }
}

# --- RDP Status ---
Section "Remote Desktop (RDP) Status"
$rdp = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections).fDenyTSConnections
$rdpStatus = if ($rdp -eq 0) { "ENABLED" } else { "Disabled" }
$rdpColor  = if ($rdp -eq 0) { "Yellow" } else { "Green" }
Write-Host "  RDP: $rdpStatus" -ForegroundColor $rdpColor
"  RDP: $rdpStatus" | Out-File $OutFile -Append

# --- UAC Status ---
Section "UAC (User Account Control)"
$uac = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA).EnableLUA
$uacStatus = if ($uac -eq 1) { "ENABLED (good)" } else { "DISABLED — security risk" }
$uacColor  = if ($uac -eq 1) { "Green" } else { "Red" }
Write-Host "  UAC: $uacStatus" -ForegroundColor $uacColor
"  UAC: $uacStatus" | Out-File $OutFile -Append

# --- Windows Defender Status ---
Section "Windows Defender"
try {
    $def = Get-MpComputerStatus
    $items = [ordered]@{
        'Real-time Protection' = $def.RealTimeProtectionEnabled
        'Antivirus Enabled'    = $def.AntivirusEnabled
        'Signature Date'       = $def.AntivirusSignatureLastUpdated.ToString('yyyy-MM-dd')
        'Quick Scan Age (days)'= $def.QuickScanAge
        'Full Scan Age (days)' = $def.FullScanAge
    }
    foreach ($k in $items.Keys) {
        $val = $items[$k]
        $color = if ($val -eq $false -or ($k -match 'Age' -and [int]$val -gt 30)) { 'Red' } else { 'Green' }
        Write-Host "  $($k.PadRight(25)): $val" -ForegroundColor $color
        "  $($k.PadRight(25)): $val" | Out-File $OutFile -Append
    }
} catch {
    Write-Host "  Could not retrieve Defender status." -ForegroundColor Red
}

# --- AutoRun / AutoPlay ---
Section "AutoRun Status (USB/Media)"
$autoRun = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name NoDriveTypeAutoRun -ErrorAction SilentlyContinue).NoDriveTypeAutoRun
if ($autoRun -eq 255) {
    Write-Host "  AutoRun: Disabled for all drives (good)" -ForegroundColor Green
    "  AutoRun: Disabled" | Out-File $OutFile -Append
} else {
    Write-Host "  AutoRun: NOT fully disabled (value: $autoRun) — consider disabling" -ForegroundColor Yellow
    "  AutoRun: Not fully disabled" | Out-File $OutFile -Append
}

Write-Host "`n================================================================" -ForegroundColor Cyan
Write-Host "  Audit complete. Report saved to: $OutFile" -ForegroundColor Green
Write-Host "================================================================`n" -ForegroundColor Cyan
Read-Host "Press Enter to exit"
