================================================================
  IT FIELD TOOLKIT — USB Script Collection
  Windows Standalone / Workgroup Environments
================================================================

USAGE
-----
1. Copy this entire folder to a USB drive.
2. On the target PC, open an elevated Command Prompt or PowerShell
   (right-click > Run as Administrator).
3. Navigate to the USB drive (e.g. E:\IT_Toolkit\).
4. Run scripts in numbered order for a full service, or jump to
   the relevant category for a targeted fix.

All logs are saved to C:\Logs\ on the target machine.

----------------------------------------------------------------
FOLDER STRUCTURE & RUN ORDER
----------------------------------------------------------------

01_System_Health\
  01_SFC_DISM_Repair.bat         <- Run first on any sick machine
  02_EventLog_Errors.ps1         <- Pull recent critical errors
  03_SystemInfo_Snapshot.bat     <- Full hardware/OS snapshot

02_Network\
  04_Net_Diagnostics.bat         <- Full network diag + log
  05_Net_Stack_Reset.bat         <- Winsock / TCP-IP reset
  06_DNS_Flush_Renew.bat         <- DNS flush + DHCP renew

03_Performance\
  07_Temp_Cleanup.bat            <- Clear Temp, Prefetch, WER
  08_Startup_Audit.ps1           <- List all startup entries
  09_Disk_Health_Check.bat       <- SMART status + chkdsk scan
  10_Perf_Snapshot.ps1           <- CPU / RAM / top processes

04_Security\
  11_Defender_Quick_Scan.bat     <- Run Windows Defender scan
  12_Firewall_Status.ps1         <- Firewall rules + status check
  13_Windows_Update_Reset.bat    <- Fix broken Windows Update
  14_Security_Audit.ps1          <- Open ports, services, users

----------------------------------------------------------------
NOTES
-----
- PowerShell scripts (.ps1) require execution policy to allow
  local scripts. If blocked, run this first in Admin PowerShell:
    Set-ExecutionPolicy RemoteSigned -Scope LocalMachine

- Scripts do NOT make permanent changes unless stated.
  Exceptions (which prompt confirmation first):
    05_Net_Stack_Reset.bat   (requires reboot)
    13_Windows_Update_Reset.bat (clears WU cache)

- All output logs saved to C:\Logs\ with timestamps.

================================================================
