@echo off
title IT Field Toolkit - Main Menu
color 1F
:MENU
cls
echo.
echo  ============================================================
echo   IT FIELD TOOLKIT  ^|  General-Purpose Windows USB Kit
echo  ============================================================
echo.
echo   [1]  System Health ^& Repair
echo        SFC, DISM, Event Log snapshot, System Info
echo.
echo   [2]  Network Reset ^& Diagnostics
echo        Full diag, stack reset, DNS flush, static-to-DHCP
echo.
echo   [3]  Performance ^& Cleanup
echo        Temp files, startup, disk usage, RAM/CPU snapshot
echo.
echo   [4]  Security Hardening
echo        Firewall check, Defender update, Windows Update,
echo        audit policy, open ports
echo.
echo   [5]  Open LOGS folder
echo.
echo   [6]  Exit
echo.
echo  ============================================================
echo   NOTE: Run this file as Administrator for full function
echo  ============================================================
echo.
set /p CHOICE= Enter number and press ENTER:

if "%CHOICE%"=="1" call "%~dp001_System_Health\RUN_ALL_SysHealth.bat"
if "%CHOICE%"=="2" call "%~dp002_Network\RUN_ALL_Network.bat"
if "%CHOICE%"=="3" call "%~dp003_Performance_Cleanup\RUN_ALL_Perf.bat"
if "%CHOICE%"=="4" call "%~dp004_Security_Hardening\RUN_ALL_Security.bat"
if "%CHOICE%"=="5" explorer "%~dp0LOGS"
if "%CHOICE%"=="6" exit

goto MENU
